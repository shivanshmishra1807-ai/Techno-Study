package com.technostudy.app;

import android.app.*;import android.os.*;import android.graphics.Color;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
 LinearLayout root, content; int blue=Color.rgb(49,87,213); TextView title;
 @Override public void onCreate(Bundle b){super.onCreate(b); showSplash();}
 TextView t(String s,int size){ TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(Color.rgb(30,35,45));v.setPadding(18,14,18,14);return v; }
 void showSplash(){ root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setBackgroundColor(Color.WHITE); TextView a=t("TECHNO STUDY",30);a.setTextColor(blue);a.setGravity(17);root.addView(a); TextView b=t("Class 10 • Learn • Practice • Achieve",16);b.setGravity(17);root.addView(b);setContentView(root);new Handler().postDelayed(this::home,900); }
 void home(){ root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(248,249,252));
  LinearLayout bar=new LinearLayout(this);bar.setPadding(10,16,10,10);title=t("Techno Study",25);title.setTextColor(blue);bar.addView(title,new LinearLayout.LayoutParams(0,-2,1));Button p=new Button(this);p.setText("Profile");p.setOnClickListener(v->profile());bar.addView(p);root.addView(bar);
  content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL); ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
  String[] cards={"📚 Subjects","🎯 Batches • ₹5","🤖 AI Doubt Solver","🏆 Leaderboard","📝 Tests & PYQs","📄 Notes & Sample Papers","🔔 Notifications","⚙ Admin Controls"};
  for(String x:cards){Button q=new Button(this);q.setText(x);q.setTextSize(17);q.setOnClickListener(v->open(x));content.addView(q,new LinearLayout.LayoutParams(-1,64));}
  setContentView(root);
 }
 void open(String x){ if(x.contains("AI")) ai(); else if(x.contains("Leaderboard")) leaderboard(); else if(x.contains("Profile")) profile(); else if(x.contains("Admin")) admin(); else { content.removeAllViews();content.addView(t(x,24));content.addView(t("यह section ready है। अपना content/admin data जोड़कर इसे live किया जा सकता है।",16));Button back=new Button(this);back.setText("← Home");back.setOnClickListener(v->home());content.addView(back);} }
 void ai(){content.removeAllViews();content.addView(t("🤖 AI Doubt Solver",25));EditText q=new EditText(this);q.setHint("अपना doubt लिखें...");content.addView(q);Button ask=new Button(this);ask.setText("Solve Doubt");content.addView(ask);TextView ans=t("AI answer यहाँ आएगा। Production में secure AI API/backend जोड़ना होगा।",16);content.addView(ans);ask.setOnClickListener(v->ans.setText("आपका doubt: "+q.getText()+"\n\nAI service connected होने पर यहाँ step-by-step solution मिलेगा."));}
 void leaderboard(){content.removeAllViews();content.addView(t("🏆 Leaderboard",25));content.addView(t("1. Student A — 980 points\n2. Student B — 920 points\n3. Student C — 875 points",18));}
 void profile(){content.removeAllViews();content.addView(t("👤 Profile",25));EditText n=new EditText(this);n.setHint("Name");content.addView(n);EditText c=new EditText(this);c.setHint("Class (10th)");content.addView(c);Button save=new Button(this);save.setText("Save Profile");content.addView(save);}
 void admin(){content.removeAllViews();content.addView(t("⚙ Admin Controls",25));String[] a={"Unlock all for Admin","Manage Batches & ₹5 price","Upload Lectures","Upload Notes/PDF","Manage PYQs & Tests","Send Notifications","Manage Leaderboard","Manage Ratings/Reviews"};for(String s:a){Switch sw=new Switch(this);sw.setText(s);sw.setTextSize(16);sw.setPadding(18,10,18,10);content.addView(sw);}}
}
